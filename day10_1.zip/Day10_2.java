package day10_1;

public class Day10_2 {

}
