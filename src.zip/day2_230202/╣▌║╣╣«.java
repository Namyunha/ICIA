package day2_230202;

public class 반복문 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	}

}
