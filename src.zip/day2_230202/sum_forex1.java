package day2_230202;

public class sum_forex1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int dan = 6;
		for (int i = 1 ; i<=9 ; i++) {
			System.out.println(dan + " * " + i + " = " + dan*i );
		}
//		
//		for(int i=2 ; i<=100 ; i=i+2) {
//			Sum = Sum + i;						
//		}
//		System.out.println("1~100까지의 짝수합은 " + Sum);

	}

}
