package day2_230202;

public class exx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println("hello");		System.out.print("hello");
		System.out.print("hello");
		
		
		
		

	}

}
