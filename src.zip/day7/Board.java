package day7;

public class Board {
//	객체를 찍어내려면 생성자가 필요하다 
	String title;
	String writer;
	int cnt;

	public Board() {

	}
	
	public Board(String title, String writer, int cnt) {
		
	}

	public void cntUp() {
		this.cnt++;
	}

}