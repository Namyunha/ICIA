package day7;

public class BoardMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		Board b1 = new Board();
//		b1.title = "자바";
//		b1.writer = "홍길동";
//		b1.cnt = 0;
//		b1.cntUp();
//		
//		Board b2 = new Board();
//		b2.writer = "리순신";
//		b2.cnt = 10;
//		b2.cntUp();
//		
	}

}
