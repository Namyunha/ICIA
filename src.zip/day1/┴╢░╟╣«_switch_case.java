package day1;

public class 조건문_switch_case {

	public static void main(String[] args) {
		int a = 8;
		switch(a) {
		case 1:
			System.out.println("1입니다.");
			break;
		case 2:
			System.out.println("2입니다.");
			break;
		case 3:
			System.out.println("3입니다.");
			break;
			
		default:
			System.out.println("1~3까지 입력해주세요");
		
		}

	}

}
