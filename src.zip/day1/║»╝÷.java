package day1;

public class 변수 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int age;
		age = 49;
		float weight = 70.44f;
		System.out.println(age);
		System.out.println(weight);
		
		age = 50;
		weight = weight + 3;
		System.out.println(age);
		System.out.println(weight);
			
		
	}

}
