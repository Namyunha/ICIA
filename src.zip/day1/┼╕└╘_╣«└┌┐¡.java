package day1;

public class 타입_문자열 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String a = "홍길동";
		String b = "심청이";
		String c = "이순신";
		System.out.println("변수 a는 "+a+" 입니다.");
		System.out.println(b);
		System.out.println(c);
		
	}

}
