package day1;

public class Ex01 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		char ban1 = 'A';
		String name1 = "홍길동";
		int kor1 = 100;
		int eng1 = 49;
		int mat1 = 89;
		int sum1 = kor1 + eng1 + mat1;
		double avg1 = sum1/3.;
		System.out.println(ban1 + " : " + name1+ " : " + kor1+ " : " + eng1+ " : " + mat1+ " : " +  avg1);
	}

}
