package day1;

public class 타입_불리언 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		boolean a = true;
		boolean b = false;
		System.out.println(a);
		System.out.println(b);
		int c = 10;
		int d = 4;
		boolean e = c > d;
		boolean f = c == d;
		System.out.println(e);
		System.out.println(f);
	}

}
