package day1;

public class 타입_형변환 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a = 10;
		double b = a;
		double c= 10.3;
		int d = (int)c; // 강제 형변환
				
	}

}

