package day6;

public class 다차원배열 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[][] num = new int[2][3];
		
		int[][] n = {{1,2,3},{4,5,6},{7,8}};
		System.out.println(n[1][2]);
		System.out.println(n[1][2]);
		System.out.println(n[2][0]);
	}

}
