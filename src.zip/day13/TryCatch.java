package day13;

public class TryCatch {
	public static void main(String[] args) {

		try {
			// 에러가 2개이상있을 때 가장먼저 나타나는 에러를 만나서 catch문을 실행하면 코드가 종료된다.
			int[] array = new int[5];
			System.out.println(9/0);
			System.out.println(array[5]);
			// 에러가 들어갈 가능성이 있는 문구
		} catch (ArithmeticException e) {
			System.out.println("0으로 나눌 수 없습니다.");
		} catch (ArrayIndexOutOfBoundsException e) {
			System.out.println("인덱스 초과!");
			// 에러의 종류를 입력하고나서 해당 에러를 마주할때 실행되기도 한다.
		} catch (Exception e) {
			System.out.println("예외발생");
			// 에러가 잡혔을 때 취할 행동
		} finally {
			System.out.println("무조건실행");
			// finally에 해당하는 코드는 무조건 실행한다.
		}
		System.out.println("프로그램 끝");
	}
}
