package day8;

public class UtilMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
