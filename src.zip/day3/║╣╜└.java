package day3;

import java.util.Scanner;

public class 복습 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		Scanner sc = new Scanner(System.in);
//		System.out.print("====입력하세요 > ");
//		int a = sc.nextInt();
//		int sum = 1;
//		for(int i = 1; i <= 100; i++) {
//			if(i%2 == 0) {
//				sum = sum + i;
//			}
//		}
//		System.out.println(sum);

//		for(int g = 2; g<10; g++) {
//			System.out.print(g+"단"+"\t");
//		}
//		for(int j = 1; j<10; j++) {
//			System.out.println();
//			for(int i = 2; i<10; i++) {
//				System.out.print(i+ "*" + j + "=" + (j*i)+"\t");
//			}
//		}

//		for(int i = 1; i < 10; i++) {
//			System.out.println(i+"단");
//			for(int j = 1; j<10; j++) {
//				System.out.println(i+"*"+j+"="+(i*j));
//			}
//		}

//		int sum = 0;
//		int i =1;
//		while(i <= 100) {
//			if(i%2 == 1) {
//				sum += i; // sum = sum +i
//			}
//			i++;
//			
//		}
//		System.out.println(sum); 연습요함
		
		
		
//		boolean check = true;
//		while(check) {
//			System.out.print("숫자입력 > ");
//			int num = sc.nextInt();
//			if(num == 0 ) {
//				break;
//			}
//			System.out.println(".");
//		}
//		System.out.println("끝");
		
//		System.out.print("숫자를 입력해주세요 > ");
		
//		int i = sc.nextInt();
//		boolean check = true;
//		while (check) {
//			if(i==0) {
//				System.out.println("3또는 5의 배수가 아닙니다.");
//			}else if (i % 3 == 0 && i % 5 == 0) {
//				System.out.println("3또는 5의 배수입니다.");
//			} else if (i % 3 == 0) {
//				System.out.println("3의 배수입니다.");
//			} else if (i % 5 == 0) {
//				System.out.println("5의 배수입니다.");
//			} else {
//				System.out.println("3또는 5의 배수가 아닙니다.");
//			}
//			System.out.print("숫자를 입력해주세요 > ");
//			i = sc.nextInt();
//		}
		
		Scanner sc = new Scanner(System.in);
		
//		System.out.println("===자판기===");
//		System.out.print("1.콜라 2.사이다 3.우유 4.종료 > ");
//		int i = sc.nextInt();
//		boolean check = true;
//		while(check) {
//			if(i == 1) {
//				System.out.println("콜라");
//				System.out.print("1.콜라 2.사이다 3.우유 4.종료 > ");
//			} else if(i ==2) {
//				System.out.println("사이다");
//				System.out.print("1.콜라 2.사이다 3.우유 4.종료 > ");
//			} else if(i ==3) {
//				System.out.println("우유");
//				System.out.print("1.콜라 2.사이다 3.우유 4.종료 > ");
//			} else if(i==4) {
//				System.out.println("종료");
//				check = false;	
//			}
//			else {
//				System.out.println("1~4중에서 골라주세요");
//			}
//			i = sc.nextInt();
//		}
		/* long money = 10000l;
		while (true) {
			if(money < 0) {
				System.out.println("음료수를 구매할 수 없습니다");
				break;
			}
			System.out.println("=====자판기=====\t현재잔액: "+money+"원");
			System.out.println("1.콜라(1000원) 2.사이다(1200원) 3.우유(1500원) 4.종료");
			System.out.print("메뉴선택> ");
			int menu = sc.nextInt();
			
			if(menu == 1) {
				int num = sc.nextInt();
				money = money - 1000;
				if(num>0) {
					money = money - (num*1000);
				}
				System.out.println("콜라 구입성공!");
			}else if(menu == 2) {
				money = money - 1200;
				System.out.println("사이다선택");
			}else if(menu == 3) {
				money = money - 1500;
				System.out.println("우유선택");
			}else if(menu == 0) {
				System.out.println("종료");
				break;
			}
			System.out.println();
		} */
		
		
		
		
		
		
		
		
	}

}
