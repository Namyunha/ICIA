package day12;

import java.util.List;
import java.util.Scanner;

import made.Visitor;

public class Util {
	Userservice service = Userservice.getInstance();
	UserRepository repository = UserRepository.getInstance();

	public int numberCheck() {
		Scanner sc = new Scanner(System.in);
		if (sc.hasNextInt()) {
			return sc.nextInt();
		}
		return -1;
	}
//	public String numberCheak() {
//		Scanner sc = new Scanner(System.in);
//		System.out.println("메뉴 >");
//		String menu = sc.next();
//		
//	}

	public void overlapCheck(UserDTO userDTO) {
		Scanner sc = new Scanner(System.in);
		for (UserDTO s : repository.list) {
			while (true) {
				if (s.getEmail().equals(userDTO.getEmail())) {
					System.out.print("중복된 아이디입니다\n다시입력 >");
					userDTO.setEmail(sc.next());
				} else if (!userDTO.getEmail().equals(s.getEmail())) {
					break;
				}
			}
		}
	}// 아이디 중복 체크만들기
}
